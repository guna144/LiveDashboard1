export class Packet {
    seq_no : number;
    payloadStr : string;
    modd : number;
}