import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Packet } from '../_model/Packet';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ServicesService {

  apiURL : string = "//localhost:5656/message/count";

  constructor(private _http : HttpClient) { }

  getCount() : Observable<any> {
    return this._http.get(this.apiURL);
  }
}
