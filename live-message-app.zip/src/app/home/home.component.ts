import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import * as Stomp from "@stomp/stompjs"
import * as SockJS from 'sockjs-client';
import { Chart } from 'chart.js';
import { ServicesService } from '../_services/services.service';
import { Packet } from '../_model/Packet';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  canvas: any;
  ctx: any;

  constructor(private apiService : ServicesService) {}

  ngOnInit() {
   
    var self = this;
    var intCount = 0;

    $(document).ready(function(){
        // $("button").click(function(){
        //     var div = $("div");  
        //     div.animate({left: '100px'}, "slow");
        //     div.animate({fontSize: '5em'}, "slow");
        // });
        
        var stompClient;
        
        /* Chart Configuration */
        var config = {
          type : 'line',
          data : {
            labels : [],
            datasets : [ {
              label : 'Message',
              backgroudColor : 'rgb(255, 99, 132)',
              borderColor : 'rgb(255, 99, 132)',
              data : [],
              fill : false
            } ]
          },
          options : {
            responsive : true,
            title : {
              display : true,
              text : 'Messages'
            },
            tooltips : {
              mode : 'index',
              intersect : false
            },
            hover : {
              mode : 'nearest',
              intersect : true
            },
            scales : {
              xAxes : [ {
                display : true,
                type : 'time',
                time : {
                  displayFormats : {
                    quarter : 'h:mm:ss a'
                  }
                },
                scaleLabel : {
                  display : true,
                  labelString : 'Time'
                }
              } ],
              yAxes : [ {
                display : true,
                scaleLabel : {
                  display : true,
                  labelString : 'Value'
                }
              } ]
            }
          }
        };
        

        this.canvas  = document.getElementById('lineChart'); //.getContext('2d');
        this.ctx = this.canvas.getContext('2d');
        var myLine = new Chart(this.ctx, config);
        /* Configuring WebSocket on Client Side */
        var socket = new SockJS('/live-messages');
        stompClient = Stomp.over(socket);
        stompClient.connect({}, function(frame) {
          stompClient.subscribe('/topic/messages', function(messages) {
            intCount++;
            
            $('#messages').text(intCount);//messages.body)+1);
            /* Push new data On X-Axis of Chart */
            config.data.labels.push(new Date());
            /* Push new data on Y-Axis of chart */
            config.data.datasets.forEach(function(dataset) {
              dataset.data.push(intCount);//messages.body);
            });
            myLine.update();
          });
        });
        //$("#btn-search").click(function(event){
          getCount(config,myLine);
       // });
    });
    
    function getCount(config,myLine) {
      // alert("config === : "+config );
      
      self.getCountAPI().subscribe(data => {
        
        data.forEach(function(packet){
          intCount++;
           /* Push new data On X-Axis of Chart */
          config.data.labels.push(new Date());
          /* Push new data on Y-Axis of chart */
          config.data.datasets.forEach(function(dataset) {
              dataset.data.push(intCount);
            });
          myLine.update();
          $('#messages').text(intCount);
        }); 
        
        $('#btn-search').prop('disabled', true);       
      });
    }
		
  }

  getCountAPI() : Observable<any> {
    return this.apiService.getCount();
  }
}
