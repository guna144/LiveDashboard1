/**
 * 
 */
package net.visionvalley.repo;

import java.util.List;
import org.springframework.data.repository.PagingAndSortingRepository;
import net.visionvalley.model.Packet;

/**
 * @author Guna Palani
 *
 */
public interface PayLoadRepo extends PagingAndSortingRepository<Packet, Long> {

	List<Packet> findAll();
}
