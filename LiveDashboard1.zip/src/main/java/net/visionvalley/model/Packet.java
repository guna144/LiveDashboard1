/**
 * 
 */
package net.visionvalley.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Guna Palani
 *
 */
@Entity
@Table(name = "payload_test")
public class Packet {

	@Id
	@Column(name = "seq_no")
	Long seq_no;
	
	@Column(name = "payloadstr")
	String payloadstr;
	
	@Column(name = "modd")
	Integer modd;

	public Long getSeq_no() {
		return seq_no;
	}

	public void setSeq_no(Long seq_no) {
		this.seq_no = seq_no;
	}

	public String getPayloadstr() {
		return payloadstr;
	}

	public void setPayloadstr(String payloadstr) {
		this.payloadstr = payloadstr;
	}

	public Integer getModd() {
		return modd;
	}

	public void setModd(Integer modd) {
		this.modd = modd;
	}
	
	
}
