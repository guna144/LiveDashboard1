/**
 * 
 */
package net.visionvalley.data;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Logger;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import com.github.shyiko.mysql.binlog.BinaryLogClient;
import com.github.shyiko.mysql.binlog.event.DeleteRowsEventData;
import com.github.shyiko.mysql.binlog.event.EventData;
import com.github.shyiko.mysql.binlog.event.TableMapEventData;
import com.github.shyiko.mysql.binlog.event.UpdateRowsEventData;
import com.github.shyiko.mysql.binlog.event.WriteRowsEventData;
import net.visionvalley.configurations.KafkaProducerConfig;
import net.visionvalley.constants.KafkaConstants;

/**
 * @author Guna Palani
 *
 */
public class DataStream {

	private static Logger LOGGER = Logger.getLogger(DataStream.class.getName());
	
	public static Producer<Long, String> producer;
	
	
	public static void liveDataStream() throws IOException {
		final Map<String, Long> tableMap = new HashMap<String, Long>();
		LOGGER.info("LIVE DATA STREAM ENTERED >>>>>>>>>>>>>>>>>> ");
//		Pusher pusher = 
//                new Pusher("<PUSHER_APP_ID>", "<PUSHER_APP_KEY>", "<PUSHER_APP_SECRET>");
//            pusher.setCluster("<PUSHER_APP_CLUSTER>");
//            pusher.setEncrypted(true);
		
//		Producer<Long, String> producer = KafkaProducerConfig.createProducer("client2");
		producer = KafkaProducerConfig.createProducer(KafkaConstants.CLIENT_ID); 
		
		BinaryLogClient client = new BinaryLogClient("localhost", 3306, "root", "VVadmin14$$");
//		BinaryLogClient client = new BinaryLogClient("192.168.200.67", 3306, "root", "root@123");
		client.registerEventListener(event -> {
			EventData data = event.getData();
			
			if(data instanceof TableMapEventData) {
				TableMapEventData tableData = (TableMapEventData) data;
				tableMap.put(tableData.getTable(), tableData.getTableId());
			}else if(data instanceof WriteRowsEventData) {
	            WriteRowsEventData eventData = (WriteRowsEventData)data;
	            LOGGER.info("tableMap ::::: "+tableMap.get("payload_test"));
	            if(eventData.getTableId() == tableMap.get("payload_test")) {
	                for(Object[] product: eventData.getRows()) {
//	                    pusher.trigger(
//                       "payload_test", "insert", getProductMap(product)
//	                    );
	                	LOGGER.info("product ::::: "+product[0]);
	                	ProducerRecord<Long, String> record = new ProducerRecord<Long,String>(KafkaConstants.TOPIC_NAME, String.valueOf(product[0]));
	                	producer.send(record);
	                }
	            }
			}else if(data instanceof UpdateRowsEventData) {
                UpdateRowsEventData eventData = (UpdateRowsEventData)data;
                if(eventData.getTableId() == tableMap.get("payload_test")) {
                    for(Entry<Serializable[], Serializable[]> row:  eventData.getRows()) {
//                        pusher.trigger(
//                          "payload_test", "update", getProductMap(row.getValue())
//                        );
                    	ProducerRecord<Long, String> record = new ProducerRecord<Long,String>(KafkaConstants.TOPIC_NAME, String.valueOf(row.getValue()[0]));
	                	producer.send(record);
                    }
                }
            }else if(data instanceof DeleteRowsEventData) {
                DeleteRowsEventData eventData = (DeleteRowsEventData)data;
                if(eventData.getTableId() == tableMap.get("payload_test")) {
                    for(Object[] product: eventData.getRows()) {
//                        pusher.trigger("payload_test", "delete", product[0]);
                    	ProducerRecord<Long, String> record = new ProducerRecord<Long,String>(KafkaConstants.TOPIC_NAME, String.valueOf(product[0]));
	                	producer.send(record);
                    }
                }
            }
            LOGGER.info("Event ::::: "+event);
        });
        client.connect();
	}

	static Map<String, String> getProductMap(Object[] product) {
        Map<String, String> map = new HashMap<>();
        map.put("seq_no", java.lang.String.valueOf(product[0]));
        map.put("payloadstr", java.lang.String.valueOf(product[1]));
        map.put("modd", java.lang.String.valueOf(product[2]));

        return map;
    }

}
