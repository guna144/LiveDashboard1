/**
 * 
 */
package net.visionvalley.data;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import net.visionvalley.model.Packet;
import net.visionvalley.repo.PayLoadRepo;

/**
 * @author Guna Palani
 *
 */
@Service
public class DataStaticDAOImpl {

	@Autowired
	private PayLoadRepo payloadRepo;
	
	public List<Packet> getAllRecords(){
		return payloadRepo.findAll();
	}
	
	
//	public List<Long> getAllRecords(){
//		Packet packet;
//		List<Long> list = new ArrayList<Long>();
//		Iterator<Packet> itr = payloadRepo.findAll().iterator();
//		while(itr.hasNext()) {
//			packet = itr.next();
//			list.add(packet.getSeq_no());
//		}
//		return list;
//	}
}
