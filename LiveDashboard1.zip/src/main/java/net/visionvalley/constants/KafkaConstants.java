/**
 * 
 */
package net.visionvalley.constants;

/**
 * @author Guna Palani
 *
 */
public interface KafkaConstants {

	public static String TOPIC_NAME = "livetemperature";
	
	public static String OFFSET_RESET_LATEST = "latest";
	 
	public static String OFFSET_RESET_EARLIER = "earliest";
	
	public static String HOST_NAME = "localhost";
	
	public static String USER_NAME = "root";
	
	public static String PASSWORD = "VVadmin14$$";
	
	public static String KAFKA_BROKERS = "localhost:9092";
	
	public static String CLIENT_ID="client1";
}
