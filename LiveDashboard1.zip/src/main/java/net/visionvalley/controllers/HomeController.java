/**
 * 
 */
package net.visionvalley.controllers;

import java.util.List;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import net.visionvalley.data.DataStaticDAOImpl;
import net.visionvalley.model.Packet;

/**
 * @author Guna Palani
 *
 */
@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
public class HomeController {
	
	@Autowired
	private DataStaticDAOImpl dataStatic;
	
	private static Logger LOGGER = Logger.getLogger(HomeController.class.getName());
	
	//Producer<Long, String> producer = KafkaProducerConfig.createProducer("client1");
	
	@GetMapping("/home")
	public String home(Model model) {
		return "home";
	}

	@GetMapping(value = "/message/count")
	public List<Packet>  searchUser() {
		return dataStatic.getAllRecords();
	}
	
//	@GetMapping("/start")
//	public List<Packet> getTotalCount() {
//		List<Long> lst =  dataStatic.getAllRecords();
//		LOGGER.info("All records >>>>>>>>>>>> : "+lst);
//		Producer<Long, String> producer = DataStream.producer;
//		LOGGER.info("producer >>>>>>>>>>>> : "+producer);
//		int intCount = 0;
//		for(Long data : lst) {
//			intCount++;
////			ProducerRecord<Long, String> record = new ProducerRecord<Long,String>(KafkaConstants.TOPIC_NAME, String.valueOf(intCount));
//			LOGGER.info("Each record records >>>>>>>>>>>> : "+String.valueOf(intCount));
////			producer.send(record);	
//		}
//		return lst;
//	}
}
