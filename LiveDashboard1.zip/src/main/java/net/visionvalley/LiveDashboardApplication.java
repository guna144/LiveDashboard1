package net.visionvalley;

import java.io.IOException;
import java.util.logging.Logger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

import net.visionvalley.data.DataStream;

@SpringBootApplication
@EnableAutoConfiguration
@Component("net.visionvalley")
public class LiveDashboardApplication {

	
	public static void main(String[] args) throws IOException {
		
		SpringApplication.run(LiveDashboardApplication.class, args);
		DataStream.liveDataStream();
	}
	
}
